import React from 'react';

import  Navigation  from './config/Navigation';

export default () => <Navigation />;
