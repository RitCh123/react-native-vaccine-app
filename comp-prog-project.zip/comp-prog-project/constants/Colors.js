
export default {
  text: '#343434',
  borderColor: '#e2e2e2',
  blue: '#4f6d7a',
  white: "#fff",
  textLight: "#797979",
  offWhite: "#CDCDCD"
};
