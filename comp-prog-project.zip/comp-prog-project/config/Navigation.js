import React from 'react';
import { TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {Entypo}  from '@expo/vector-icons';

import Home from '../screens/Home';

import StateList from '../screens/StateList';
import VaccineList from "../screens/VaccineList"

import ResultsPage from "../screens/ResultPage"

import colors from '../constants/Colors';
const MainStack = createStackNavigator();

const MainStackScreen = () => (
  <MainStack.Navigator>
    <MainStack.Screen
      name="Home"
      component={Home}
      options={({ navigation, route }) => ({
        itemSelected: route.params && route.params.itemSelected,
        headerShown:false
      })}
    />
    
  </MainStack.Navigator>
);

const ModalStack = createStackNavigator();
const ModalStackScreen = () => (
  <ModalStack.Navigator mode="modal">
    <ModalStack.Screen
      name="Home"
      component={MainStackScreen}
      options={({ navigation, route }) => ({
        itemSelected: "HOOHAA",
        headerShown:false
      })}
    />
    <ModalStack.Screen
      name="StateList"
      component={StateList}
      options={({ navigation, route }) => ({
        title: route.params && route.params.title,
        headerLeft: null,
        headerRight: () => (
          <TouchableOpacity
            onPress={() => navigation.pop()}
            style={{ paddingHorizontal: 10 }}
          >
            <Entypo name="cross" size={30} color={colors.blue} />
          </TouchableOpacity>
        ),
      })}
    />
    <ModalStack.Screen
      name="VaccineList"
      component={VaccineList}
      options={({ navigation, route }) => ({
        title: route.params && route.params.title,
        headerLeft: null,
        headerRight: () => (
          <TouchableOpacity
            onPress={() => navigation.pop()}
            style={{ paddingHorizontal: 10 }}
          >
            <Entypo name="cross" size={30} color={colors.blue} />
          </TouchableOpacity>
        ),
      })}
    />
     <ModalStack.Screen
      name="Query Results"
      component={ResultsPage}
      options={({ navigation, route }) => ({
        
      })}
    />
  </ModalStack.Navigator>
);

export default () => (
  <NavigationContainer>
    <ModalStackScreen />
  </NavigationContainer>
);