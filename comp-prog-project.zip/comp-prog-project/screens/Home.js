import React, { useState, useCallback } from 'react';

import {
  View,
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  Alert,
  Linking,
} from 'react-native';

import { Input } from '../components/Input';

import VaccineList from './VaccineList';

const screenWidth = Dimensions.get('window').width;

const vaccineSpotterUrl = 'https://vaccinespotter.org';

const unicefDonate =
  'https://www.unicef.org/coronavirus/solidarity-response-fund';




const OpenURLButton = ({ url, color, children }) => {
  const handlePress = useCallback(async () => {
    // Checking if the link is supported for links with custom URL scheme.
    const supported = await Linking.canOpenURL(url);

    if (supported) {
      // Opening the link with some app, if the URL scheme is "http" the web link should be opened
      // by some browser in the mobile
      await Linking.openURL(url);
    } else {
      Alert.alert(`Don't know how to open this URL: ${url}`);
    }
  }, [url]);

  return (
    <View style={{ color: { color }, borderRadius: 9 }}>
      <TouchableOpacity onPress={handlePress}>
        <Text style={{ fontSize: 20 }}>{children}</Text>
      </TouchableOpacity>
    </View>
  );
};
export default ({ navigation, route }) => {
  const [baseVaccine, setBaseVaccine] = useState('');
  const [baseState, setBaseState] = useState('');
  return (
    <SafeAreaView style={{ backgroundColor: '#6495ed', flex: 1 }}>
      <ScrollView>
        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
          <Image
            source={require('../assets/logo.png')}
            style={styles.image}
          />
        </View>
        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
          <Text style={styles.text}> Vaccine Spotter</Text>
        </View>
        <View style={{ height: 20 }}></View>
        <View>
          <Text
            style={{
              alignItems: 'flex-start',
              fontSize: 20,
              marginLeft: 10,
              fontWeight: 'bold',
            }}>
            Name of Vaccine:
          </Text>
        </View>
        <View style={{ height: 5 }}></View>
        <View style={{ flexDirection: 'column' }}>
          <Input
            placeholder="Vaccine"
            name="stopwatch"
            onFocus={() =>
              navigation.navigate('VaccineList', {
                title: 'List of Vaccines',
                activeVaccine: { baseVaccine },
                onChange: (value) => setBaseVaccine(value),
              })
            }
            value={baseVaccine}
          />
          <View style={{ height: 7 }}></View>
          <View style={{ height: 20 }}></View>
          <View style={{ height: 20 }}>
            <Text
              style={{
                alignItems: 'flex-start',
                fontSize: 20,
                marginLeft: 10,
                fontWeight: 'bold',
              }}>
              State:
            </Text>
            <View style={{ height: 7 }}></View>
          </View>
          <Input
            placeholder="State"
            name="location"
            
            onFocus={() =>
              navigation.push('StateList', {
                title: 'List of States',
                activeState: null,
                onChange: (value) => setBaseState(value),
              })
            }
            value={baseState}
          />
        </View>
        <View style={{ height: 20 }}></View>
        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
          <TouchableOpacity
            style={styles.touch}
            onPress={() => {
              
              if (baseState !="" && baseVaccine!="") {
                navigation.push('Query Results', {
                  stateName: baseState,
                  vaccineName: baseVaccine,
                });
              } else {
                Alert.alert(
                  'Fields Incomplete',
                  'The following fields: Vaccine or State are missing. Please select the appropriate option.'
                );
              }
            }}>
            <Text style={styles.button}>Search</Text>
          </TouchableOpacity>
        </View>
        <View style={{ height: 20 }}></View>
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            alignContent: 'center',
          }}>
          <Text style={{ fontSize: 20, color: 'white' }}>
            This app tracks only vaccines the United States. We use data from
            select pharamcies to gather appointment dates and other information.{' '}
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            margin: 10,
          }}>
          <View
            style={{ backgroundColor: 'orange', padding: 10, borderRadius: 9 }}>
            <OpenURLButton url={vaccineSpotterUrl}>
              Vaccine Spotter
            </OpenURLButton>
          </View>
          <View
            style={{
              backgroundColor: '#90ee90',
              padding: 10,
              borderRadius: 9,
            }}>
            <OpenURLButton url={unicefDonate}>Donate to UNICEF</OpenURLButton>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  image: {
    height: 120,
    width: 120,
    marginTop: 75,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 40,
    color: 'white',
    paddingTop: 20,
    fontWeight: 'bold',
    alignItems: 'center',
    justifyContent: 'center',
  },

  touch: {
    height: 40,
    width: screenWidth * 0.8,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 9,

    backgroundColor: '#d3d3d3',
  },
  button: {
    fontSize: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
