import React, { useEffect, useState, useCallback } from 'react';

import {
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  Dimensions,
  Linking,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
  ScrollView,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import VaccineRow from '../components/VaccineRow';
import stateCoordinates from '../data/stateCoordinates.json';
import Notification from '../components/Notification';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

export default ({ navigation, route }) => {
  const params = route.params;
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [latitude, setLatitude] = useState();
  const [longtitude, setLongtitude] = useState();
  const [propData, setPropData] = useState([]);

  var stateAbb = params.stateName.slice(
    params.stateName.length - 2,
    params.stateName.length
  );

  const getCoordinatesOfCity = () => {
    stateCoordinates.coordinates.map((item) => {
      if (item.stateName == stateAbb) {
        var itemLat = item.latitude;
        var itemLong = item.longtitude;
        global.itemLat = itemLat;
        global.itemLong = itemLong;

        return [itemLat, itemLong];
      }
    });
  };
  getCoordinatesOfCity();
  useEffect(() => {
    fetch('https://www.vaccinespotter.org/api/v0/states/' + stateAbb + '.json')
      .then((response) => response.json())
      .then((json) => {
        setData(json.metadata);

        setPropData(json.features);
      })
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, [stateAbb]);

  const OpenURLButton = ({ url }) => {
    Linking.canOpenURL(url)
      .then((supported) => {
        if (!supported) {
          console.log("Can't handle url: " + url);
        } else {
          return Linking.openURL(url);
        }
      })
      .catch((err) => console.error('An error occurred', err));
  };

  return (
    <View style={{ flex: 1, paddingLeft: 10, paddingRight: 10 }}>
      {isLoading ? (
        <ActivityIndicator />
      ) : (
        /*<FlatList
          data={data}
          keyExtractor={({ id }, index) => id}
          renderItem={({ item }) => (
            <Text>{item.url}, {item.name}</Text>
          )}
        /> */
        <Text>{data.url}</Text>
      )}
      <Notification stateName={stateAbb} />
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: itemLat,
          longitude: itemLong,
          //zoom is decided through trial and error
          latitudeDelta: 1.8766,
          longitudeDelta: 1.8766,
        }}>
        <MapView.Marker
            coordinate={{latitude: 37.78825,
            longitude: -122.4324}}
            title={"title"}
            description={"description"}
         />
        {propData.map((item) => {
          
          return (
            <MapView.Marker
            coordinate={{latitude: item.geometry.coordinates[1],
            longitude: item.geometry.coordinates[0]}}
            title={item.properties.name}
            description={item.properties.address}
         />
          );
        })}
      </MapView>
      <View>
        <Text style={{ marginTop: 10, fontSize: 24, marginBottom: 10 }}>
          Scanning {data.store_count} vaccine locations...
        </Text>
      </View>

      {isLoading ? (
        <ActivityIndicator />
      ) : (
        <FlatList
          data={propData}
          keyExtractor={({ id }, index) => id}
          renderItem={({ item }) => (
            <VaccineRow
              name={item.properties.name}
              url={item.properties.url}
              vaccineName={''}
              enabled={false}
              address={item.properties.address}
              //figure out the onpress as a dummy
              onPress={() => Linking.openURL(item.properties.url)}
              data={item.properties.appoiments}
            />
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  map: {
    height: screenHeight / 3,
    //the width is 20 less than the total so then the net margin would be 10px
    width: screenWidth - 20,
    marginTop: 20,
    marginRight: 10,
  },
});
