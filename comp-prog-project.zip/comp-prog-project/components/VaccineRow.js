import React from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  ScrollView,
} from 'react-native';

import vaccineOrder from './vaccineOrderPoint'

import Moment from 'moment';
import { Avatar, Button, Card, Title, Paragraph } from 'react-native-paper';

import { AntDesign } from '@expo/vector-icons';

import { format } from 'date-fns';

import Unorderedlist from 'react-native-unordered-list';

export default function VaccineRow({
  name,
  url,
  vaccineName,
  data,
  address,
  onPress,
}) {
  const screenWidth = Dimensions.get('window').width;
  const date = new Date();

  const AvailableVaccines = ({data}) => {
    if (!data) {
      return (
        <Text style={{fontSize: 24, color:"green", paddingBottom:13}}>Check provider website for details: No appointments</Text>
      )
    } else {
      
      data.map((item) => {
        var date = item.time
        return (
          <vaccineOrder text={Moment(date).format('d MMM')}/>
        )
      }
      )

    }

  }

  
    
  
  
  
  return (
      <View style={{ marginBottom: 10 }}>
      <ScrollView>
        <Card>
          <Card.Content>
            <Title style={{ fontSize: 25 }}>
              {name}: {vaccineName} {address}
            </Title>

            <View style={{ flexDirection: 'row' }}>
              <Paragraph
                style={{
                  fontSize: 25,
                  justifyContent: 'center',
                  alignItems: 'center',
                  paddingTop: 15,
                }}>{`Updated ${format(date, 'MMMM do yyyy')}`}</Paragraph>
              <View style={{justifyContent:"center", alignItems:"center", paddingLeft:10}}>
                <AntDesign name="checkcircleo" size={24} color="black" />
              </View>
            </View>
            <Paragraph style={{fontSize:24, paddingTop:15}}>Available Appointments: </Paragraph>
            
            
            <AvailableVaccines data={data} />
            <Paragraph>
              <View style={{ backgroundColor: '#ffc1c1', borderRadius: 5 }}>
                <TouchableOpacity
                  style={{ width: screenWidth * 0.75, padding: 15 }}
                  onPress={onPress}>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={{ fontSize: 24 }}>Visit {name}</Text>
                    <AntDesign
                      name="arrowright"
                      size={24}
                      color="black"
                      style={{ justifyContent: 'center', alignItems: 'center' }}
                    />
                  </View>
                </TouchableOpacity>
              </View>
            </Paragraph>
          </Card.Content>
        </Card>
      </ScrollView>
    </View>

    )
  }  
